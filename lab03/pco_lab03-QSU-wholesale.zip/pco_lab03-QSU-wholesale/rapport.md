**IMPORTANT ! Ce chablon est donné à titre d'exemple ! Vous êtes entièrement libres de rajouter des sections ou des informations qui vous semblent pertinentes dans le rapport. N'oubliez pas de rendre seulement un PDF nommé rapport.pdf.**


# Titre du laboratoire

Auteurs: Quentin Surdez, Rachel Tranchida

## Description des fonctionnalités du logiciel



## Choix d'implémentation

Comment avez-vous abordé le problème, quels choix avez-vous fait, quelle 
décomposition avez-vous choisie, quelles variables ont dû être protégées, ...



## Tests effectués


Description de chaque test, et information sur le fait qu'il ait passé ou non
